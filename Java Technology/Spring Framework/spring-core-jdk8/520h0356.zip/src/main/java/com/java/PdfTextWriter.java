package com.java;

import java.io.FileWriter;
import java.io.IOException;

public class PdfTextWriter implements TextWriter {
    @Override
    public void write(String fileName, String text) throws IOException {
        String path = "./" + fileName + ".pdf";
        FileWriter writer = new FileWriter(path);
        writer.write(text);
        writer.close();
    }

}
