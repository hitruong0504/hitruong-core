package com.java;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import java.io.IOException;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args ) throws IOException {
//        ApplicationContext ct = new ClassPathXmlApplicationContext("beans.xml");
//
//        Product p = ct.getBean("product3", Product.class);
//        System.out.println(p);

        ApplicationContext ct2 = new AnnotationConfigApplicationContext(BeanConfig.class);
//        Product p2 = ct2.getBean("product1", Product.class);
        Product p2 = ct2.getBean(Product.class);
        System.out.println(p2);

        TextEditor editor = ct2.getBean(TextEditor.class);
        editor.input("Hello World");
        editor.save("hello");

    }
}
