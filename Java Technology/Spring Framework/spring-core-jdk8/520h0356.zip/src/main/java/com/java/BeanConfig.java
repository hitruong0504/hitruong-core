package com.java;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.Scope;

@ComponentScan
@PropertySource("example.properties")
public class BeanConfig {


//    @Bean
//    public Product product1() {
//        Product p = new Product();
//        p.setId(1);
//        p.setName("iPhone 11 Pro Max");
//        p.setPrice(1099);
//        p.setColor("Gold");
//        return p;
//    }
//
//    @Bean
//    @Scope("Singleton")
//    public Product product2() {
//        return new Product(2, "iPhone 12 Pro Max", 1199, "Silver");
//    }
//
//
//    @Bean
//    public Product product3() {
//        return new Product(3, "iPhone 13 Pro Max", 1099, "Blue");
//    }
//
//
//    @Bean(name = "plain")
//    public TextWriter plainTextWriter() {
//        return new PlainTextWriter();
//    }
//
//    @Bean(name = "pdf")
//    public TextWriter pdfTextWriter() {
//        return new PdfTextWriter();
//    }
//
//    @Bean
//    @Autowired
//    public TextEditor textEditor(@Qualifier("plain") TextWriter textWriter) {
//        return new TextEditor(textWriter);
//    }
}
