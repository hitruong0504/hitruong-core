package com.java;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.io.IOException;
@Component
public class TextEditor {

    private String inputText;
    private TextWriter writer;

    public TextEditor() {
        System.out.println("TextEditor constructor");
    }

    public TextEditor(TextWriter writer) {
        this.writer = writer;
    }
    public void save(String text) throws IOException {
        writer.write(text, inputText);
    }

    public void input(String text) {
        this.inputText = text;
    }
}
