package com.java;

import java.io.FileWriter;
import java.io.IOException;

public class PlainTextWriter implements TextWriter {

    public PlainTextWriter() {
    }

    @Override
    public void write(String fileName, String text) throws IOException {
        String path = "./" + fileName + ".txt";
        FileWriter writer = new FileWriter(path);
        writer.write(text);
        writer.close();
    }
}
